import { spawn, ChildProcess } from "child_process";
import { logger } from "../utils/globalLogger.js";
import { stripAnsiColors } from "../utils/stringUtils.js";
import { handleLargeOutput } from "../utils/largeOutputHandler.js";
import type { ToolPlugin, ToolResult, ToolContext } from "./types.js";

/**
 * Bash command execution tool - supports both foreground and background execution
 */
export const bashTool: ToolPlugin = {
  name: "Bash",
  config: {
    type: "function",
    function: {
      name: "Bash",
      description:
        "Executes a given bash command in a persistent shell session with optional timeout, ensuring proper handling and security measures.",
      parameters: {
        type: "object",
        properties: {
          command: {
            type: "string",
            description: "The command to execute",
          },
          timeout: {
            type: "number",
            description: "Optional timeout in milliseconds (max 600000)",
          },
          description: {
            type: "string",
            description:
              "Clear, concise description of what this command does in 5-10 words.",
          },
          run_in_background: {
            type: "boolean",
            description:
              "Set to true to run this command in the background. Use BashOutput to read the output later.",
          },
        },
        required: ["command"],
      },
    },
  },
  execute: async (
    args: Record<string, unknown>,
    context: ToolContext,
  ): Promise<ToolResult> => {
    const command = args.command as string;
    const runInBackground = args.run_in_background as boolean | undefined;
    const description = args.description as string | undefined;
    // Set default timeout: 60s for foreground, no timeout for background
    const timeout =
      (args.timeout as number | undefined) ??
      (runInBackground ? undefined : 60000);

    if (!command || typeof command !== "string") {
      return {
        success: false,
        content: "",
        error: "Command parameter is required and must be a string",
      };
    }

    // Validate timeout
    if (
      timeout !== undefined &&
      (typeof timeout !== "number" || timeout < 0 || timeout > 600000)
    ) {
      return {
        success: false,
        content: "",
        error: "Timeout must be a number between 0 and 600000 milliseconds",
      };
    }

    // Permission check after validation but before real operation
    if (
      context.permissionManager &&
      context.permissionMode &&
      context.permissionMode !== "bypassPermissions"
    ) {
      if (context.permissionManager.isRestrictedTool("Bash")) {
        try {
          const permissionContext = context.permissionManager.createContext(
            "Bash",
            context.permissionMode,
            context.canUseToolCallback,
            {
              command,
              description,
              run_in_background: runInBackground,
              timeout,
            },
          );
          const permissionResult =
            await context.permissionManager.checkPermission(permissionContext);

          if (permissionResult.behavior === "deny") {
            return {
              success: false,
              content: "",
              error:
                permissionResult.message ||
                "Bash operation denied by permission system",
            };
          }
        } catch {
          return {
            success: false,
            content: "",
            error: "Permission check failed",
          };
        }
      }
    }

    if (runInBackground) {
      // Background execution
      const backgroundBashManager = context?.backgroundBashManager;
      if (!backgroundBashManager) {
        return {
          success: false,
          content: "",
          error: "Background bash manager not available",
        };
      }

      const shellId = backgroundBashManager.startShell(command, timeout);
      return {
        success: true,
        content: `Command started in background with ID: ${shellId}. Use BashOutput tool with bash_id="${shellId}" to monitor output.`,
        shortResult: `Background process ${shellId} started`,
      };
    }

    // Foreground execution (original behavior)
    return new Promise((resolve) => {
      const child: ChildProcess = spawn(command, {
        shell: true,
        stdio: "pipe",
        cwd: context.workdir,
        env: {
          ...process.env,
        },
      });

      let outputBuffer = "";
      let errorBuffer = "";
      let isAborted = false;

      // Set up timeout
      let timeoutHandle: NodeJS.Timeout | undefined;
      if (timeout && timeout > 0) {
        timeoutHandle = setTimeout(() => {
          if (!isAborted) {
            handleAbort("Command timed out");
          }
        }, timeout);
      }

      // Handle abort signal
      const handleAbort = (reason = "Command execution was aborted") => {
        if (!isAborted) {
          isAborted = true;

          if (timeoutHandle) {
            clearTimeout(timeoutHandle);
          }

          // Force terminate child process and its children
          if (child.pid) {
            try {
              // Try graceful termination of process group
              process.kill(-child.pid, "SIGTERM");

              // Set timeout for force kill
              setTimeout(() => {
                if (child.pid && !child.killed) {
                  try {
                    process.kill(-child.pid, "SIGKILL");
                  } catch (killError) {
                    logger.error("Failed to force kill process:", killError);
                  }
                }
              }, 1000);
            } catch {
              // If process group termination fails, try direct child process termination
              try {
                child.kill("SIGTERM");
                setTimeout(() => {
                  if (!child.killed) {
                    child.kill("SIGKILL");
                  }
                }, 1000);
              } catch (directKillError) {
                logger.error("Failed to kill child process:", directKillError);
              }
            }
          }

          resolve({
            success: false,
            content: outputBuffer + (errorBuffer ? "\n" + errorBuffer : ""),
            error: reason,
          });
        }
      };

      // Handle abort signal from context
      if (context?.abortSignal) {
        if (context.abortSignal.aborted) {
          handleAbort();
          return;
        }
        // Use { once: true } to prevent listener accumulation on signal reuse
        context.abortSignal.addEventListener("abort", () => handleAbort(), {
          once: true,
        });
      }

      child.stdout?.on("data", (data) => {
        if (!isAborted) {
          outputBuffer += stripAnsiColors(data.toString());
        }
      });

      child.stderr?.on("data", (data) => {
        if (!isAborted) {
          errorBuffer += stripAnsiColors(data.toString());
        }
      });

      child.on("exit", (code) => {
        if (!isAborted) {
          if (timeoutHandle) {
            clearTimeout(timeoutHandle);
          }

          const exitCode = code ?? 0;
          const combinedOutput =
            outputBuffer + (errorBuffer ? "\n" + errorBuffer : "");

          // Handle large output by writing to temp file if needed
          const finalOutput =
            combinedOutput || `Command executed with exit code: ${exitCode}`;
          handleLargeOutput(finalOutput)
            .then(({ content, filePath }) => {
              resolve({
                success: exitCode === 0,
                content,
                filePath,
                error:
                  exitCode !== 0
                    ? `Command failed with exit code: ${exitCode}`
                    : undefined,
              });
            })
            .catch((error) => {
              logger.warn(`Error handling large output: ${error}`);
              resolve({
                success: exitCode === 0,
                content: finalOutput,
                error:
                  exitCode !== 0
                    ? `Command failed with exit code: ${exitCode}`
                    : undefined,
              });
            });
        }
      });

      child.on("error", (error) => {
        if (!isAborted) {
          if (timeoutHandle) {
            clearTimeout(timeoutHandle);
          }
          resolve({
            success: false,
            content: "",
            error: `Failed to execute command: ${error.message}`,
          });
        }
      });
    });
  },
  formatCompactParams: (params: Record<string, unknown>) => {
    const description = params.description as string;
    const command = params.command as string;
    const runInBackground = params.run_in_background as boolean;

    if (description) {
      return description;
    }

    return `${command}${runInBackground ? " (background)" : ""}`;
  },
};

/**
 * BashOutput tool - retrieves output from background bash shells
 */
export const bashOutputTool: ToolPlugin = {
  name: "BashOutput",
  config: {
    type: "function",
    function: {
      name: "BashOutput",
      description:
        "Retrieves output from a running or completed background bash shell",
      parameters: {
        type: "object",
        properties: {
          bash_id: {
            type: "string",
            description:
              "The ID of the background shell to retrieve output from",
          },
          filter: {
            type: "string",
            description:
              "Optional regular expression to filter the output lines. Only lines matching this regex will be included in the result. Any lines that do not match will no longer be available to read.",
          },
        },
        required: ["bash_id"],
      },
    },
  },
  execute: async (
    args: Record<string, unknown>,
    context: ToolContext,
  ): Promise<ToolResult> => {
    const bashId = args.bash_id as string;
    const filter = args.filter as string | undefined;

    if (!bashId || typeof bashId !== "string") {
      return {
        success: false,
        content: "",
        error: "bash_id parameter is required and must be a string",
      };
    }

    const backgroundBashManager = context?.backgroundBashManager;
    if (!backgroundBashManager) {
      return {
        success: false,
        content: "",
        error: "Background bash manager not available",
      };
    }

    const output = backgroundBashManager.getOutput(bashId, filter);
    if (!output) {
      return {
        success: false,
        content: "",
        error: `Background shell with ID ${bashId} not found`,
      };
    }

    const shell = backgroundBashManager.getShell(bashId);
    if (!shell) {
      return {
        success: false,
        content: "",
        error: `Background shell with ID ${bashId} not found`,
      };
    }

    let content = "";
    if (output.stdout) {
      content += stripAnsiColors(output.stdout);
    }
    if (output.stderr) {
      content += (content ? "\n" : "") + stripAnsiColors(output.stderr);
    }

    const finalContent = content || "No output available";
    const { content: processedContent, filePath } =
      await handleLargeOutput(finalContent);

    return {
      success: true,
      content: processedContent,
      filePath,
      shortResult: `${bashId}: ${output.status}${shell.exitCode !== undefined ? ` (${shell.exitCode})` : ""}`,
      error: undefined,
    };
  },
  formatCompactParams: (params: Record<string, unknown>) => {
    const bashId = params.bash_id as string;
    const filter = params.filter as string | undefined;
    return filter ? `${bashId} filtered: ${filter}` : bashId;
  },
};

/**
 * KillBash tool - kills a running background bash shell
 */
export const killBashTool: ToolPlugin = {
  name: "KillBash",
  config: {
    type: "function",
    function: {
      name: "KillBash",
      description: "Kills a running background bash shell by its ID",
      parameters: {
        type: "object",
        properties: {
          shell_id: {
            type: "string",
            description: "The ID of the background shell to kill",
          },
        },
        required: ["shell_id"],
      },
    },
  },
  execute: async (
    args: Record<string, unknown>,
    context: ToolContext,
  ): Promise<ToolResult> => {
    const shellId = args.shell_id as string;

    if (!shellId || typeof shellId !== "string") {
      return {
        success: false,
        content: "",
        error: "shell_id parameter is required and must be a string",
      };
    }

    const backgroundBashManager = context?.backgroundBashManager;
    if (!backgroundBashManager) {
      return {
        success: false,
        content: "",
        error: "Background bash manager not available",
      };
    }

    const shell = backgroundBashManager.getShell(shellId);
    if (!shell) {
      return {
        success: false,
        content: "",
        error: `Background shell with ID ${shellId} not found`,
      };
    }

    if (shell.status !== "running") {
      return {
        success: false,
        content: "",
        error: `Background shell ${shellId} is not running (status: ${shell.status})`,
      };
    }

    const killed = backgroundBashManager.killShell(shellId);
    if (killed) {
      return {
        success: true,
        content: `Background shell ${shellId} has been killed`,
        shortResult: `Killed ${shellId}`,
      };
    } else {
      return {
        success: false,
        content: "",
        error: `Failed to kill background shell ${shellId}`,
      };
    }
  },
  formatCompactParams: (params: Record<string, unknown>) => {
    const shellId = params.shell_id as string;
    return shellId;
  },
};
