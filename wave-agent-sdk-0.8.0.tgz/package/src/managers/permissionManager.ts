/**
 * Permission Manager for handling tool permission checks
 *
 * This manager provides utilities for checking permissions before tool execution.
 * It implements the permission logic for different modes (default vs bypass) and
 * handles custom callback integration.
 */

import path from "node:path";
import { minimatch } from "minimatch";
import type {
  PermissionDecision,
  ToolPermissionContext,
  PermissionCallback,
  PermissionMode,
} from "../types/permissions.js";
import { RESTRICTED_TOOLS } from "../types/permissions.js";
import type { Logger } from "../types/index.js";
import {
  splitBashCommand,
  stripEnvVars,
  stripRedirections,
  getSmartPrefix,
  DANGEROUS_COMMANDS,
} from "../utils/bashParser.js";
import { isPathInside } from "../utils/pathSafety.js";
import {
  BASH_TOOL_NAME,
  EDIT_TOOL_NAME,
  WRITE_TOOL_NAME,
  READ_TOOL_NAME,
  LS_TOOL_NAME,
} from "../constants/tools.js";
import { Container } from "../utils/container.js";
import { ConfigurationService } from "../services/configurationService.js";

const SAFE_COMMANDS = ["cd", "ls", "pwd", "true", "false"];

const DEFAULT_ALLOWED_RULES = [
  "Bash(git status*)",
  "Bash(git diff*)",
  "Bash(git log*)",
  "Bash(git show*)",
  "Bash(git branch*)",
  "Bash(git tag*)",
  "Bash(git remote*)",
  "Bash(git ls-files*)",
  "Bash(git rev-parse*)",
  "Bash(git config --list*)",
  "Bash(git config -l*)",
  "Bash(git cat-file*)",
  "Bash(git count-objects*)",
  "Bash(echo*)",
  "Bash(which*)",
  "Bash(type*)",
  "Bash(hostname*)",
  "Bash(whoami*)",
  "Bash(date*)",
  "Bash(uptime*)",
];

import { logger } from "../utils/globalLogger.js";

export interface PermissionManagerOptions {
  /** Configured default permission mode from settings */
  configuredDefaultMode?: PermissionMode;
  /** Allowed rules from settings */
  allowedRules?: string[];
  /** Denied rules from settings */
  deniedRules?: string[];
  /** Additional directories considered part of the Safe Zone */
  additionalDirectories?: string[];
  /** The main working directory */
  workdir?: string;
  /** Path to the current plan file */
  planFilePath?: string;
  /** Optional logger */
  logger?: Logger;
}

export class PermissionManager {
  private configuredDefaultMode?: PermissionMode;
  private allowedRules: string[] = [];
  private deniedRules: string[] = [];
  private temporaryRules: string[] = [];
  private additionalDirectories: string[] = [];
  private workdir?: string;
  private planFilePath?: string;
  private onConfiguredDefaultModeChange?: (mode: PermissionMode) => void;
  private _logger?: Logger;

  constructor(
    private container: Container,
    options: PermissionManagerOptions = {},
  ) {
    this.configuredDefaultMode = options.configuredDefaultMode;
    this.allowedRules = options.allowedRules || [];
    this.deniedRules = options.deniedRules || [];
    this.workdir = options.workdir;
    this.planFilePath = options.planFilePath;
    this._logger = options.logger;
    this.updateAdditionalDirectories(options.additionalDirectories || []);
  }

  /**
   * Set a callback to be notified when the effective permission mode changes due to configuration updates
   */
  public setOnConfiguredDefaultModeChange(
    callback: (mode: PermissionMode) => void,
  ): void {
    this.onConfiguredDefaultModeChange = callback;
  }

  /**
   * Update the configured default mode (e.g., when configuration reloads)
   */
  updateConfiguredDefaultMode(defaultMode?: PermissionMode): void {
    const oldEffectiveMode = this.getCurrentEffectiveMode();

    this.configuredDefaultMode = defaultMode;

    const newEffectiveMode = this.getCurrentEffectiveMode();
    if (
      oldEffectiveMode !== newEffectiveMode &&
      this.onConfiguredDefaultModeChange
    ) {
      this.onConfiguredDefaultModeChange(newEffectiveMode);
    }
  }

  /**
   * Get the configured default mode
   */
  public getConfiguredDefaultMode(): PermissionMode | undefined {
    return this.configuredDefaultMode;
  }

  /**
   * Get all currently allowed rules (user-defined)
   */
  public getAllowedRules(): string[] {
    return [...this.allowedRules];
  }

  /**
   * Get all currently denied rules
   */
  public getDeniedRules(): string[] {
    return [...this.deniedRules];
  }

  /**
   * Get all additional directories
   */
  public getAdditionalDirectories(): string[] {
    return [...this.additionalDirectories];
  }

  /**
   * Get all default allowed rules
   */
  public getDefaultAllowedRules(): string[] {
    return [...DEFAULT_ALLOWED_RULES];
  }

  /**
   * Update the allowed rules (e.g., when configuration reloads)
   */
  updateAllowedRules(rules: string[]): void {
    this.allowedRules = rules;
  }

  /**
   * Update the denied rules (e.g., when configuration reloads)
   */
  updateDeniedRules(rules: string[]): void {
    this.deniedRules = rules;
  }

  /**
   * Add temporary rules for the current session
   */
  public addTemporaryRules(rules: string[]): void {
    this.temporaryRules.push(...rules);
  }

  /**
   * Clear all temporary rules
   */
  public clearTemporaryRules(): void {
    this.temporaryRules = [];
  }

  /**
   * Update the additional directories (e.g., when configuration reloads)
   */
  updateAdditionalDirectories(directories: string[]): void {
    this.additionalDirectories = directories.map((dir) => {
      if (this.workdir && !path.isAbsolute(dir)) {
        return path.resolve(this.workdir, dir);
      }
      return path.resolve(dir);
    });
  }

  /**
   * Update the working directory
   */
  updateWorkdir(workdir: string): void {
    this.workdir = workdir;
  }

  /**
   * Set the current plan file path
   */
  public setPlanFilePath(path: string | undefined): void {
    this.planFilePath = path;
  }

  /**
   * Get the current plan file path
   */
  public getPlanFilePath(): string | undefined {
    return this.planFilePath;
  }

  /**
   * Check if a path is inside the Safe Zone (workdir + additionalDirectories)
   */
  private isInsideSafeZone(
    targetPath: string,
    workdir?: string,
  ): { isInside: boolean; resolvedPath: string } {
    const effectiveWorkdir = workdir || this.workdir;

    // Resolve the target path relative to effectiveWorkdir if it's not absolute
    const absolutePath =
      effectiveWorkdir && !path.isAbsolute(targetPath)
        ? path.resolve(effectiveWorkdir, targetPath)
        : path.resolve(targetPath);

    // Check workdir
    if (effectiveWorkdir && isPathInside(absolutePath, effectiveWorkdir)) {
      return { isInside: true, resolvedPath: absolutePath };
    }

    // Check additional directories
    for (const dir of this.additionalDirectories) {
      if (isPathInside(absolutePath, dir)) {
        return { isInside: true, resolvedPath: absolutePath };
      }
    }

    return { isInside: false, resolvedPath: absolutePath };
  }

  /**
   * Get the current effective permission mode for tool execution context
   */
  getCurrentEffectiveMode(cliPermissionMode?: PermissionMode): PermissionMode {
    return this.resolveEffectivePermissionMode(cliPermissionMode);
  }

  /**
   * Resolve the effective permission mode based on CLI override and configured default
   */
  resolveEffectivePermissionMode(
    cliPermissionMode?: PermissionMode,
  ): PermissionMode {
    // CLI override takes highest precedence
    if (cliPermissionMode !== undefined) {
      return cliPermissionMode;
    }

    // Use configured default mode if available
    if (this.configuredDefaultMode !== undefined) {
      return this.configuredDefaultMode;
    }

    // Fall back to system default
    return "default";
  }

  /**
   * Check if a tool execution requires permission and handle the authorization flow
   * Called by individual tools after validation/diff, before real operation
   */
  async checkPermission(
    context: ToolPermissionContext,
  ): Promise<PermissionDecision> {
    // 0. Check denied rules first - Deny always takes precedence
    for (const rule of this.deniedRules) {
      if (this.matchesRule(context, rule)) {
        logger?.warn("Permission denied by rule", {
          toolName: context.toolName,
          rule,
        });
        return {
          behavior: "deny",
          message: `Access to tool '${context.toolName}' is explicitly denied by rule: ${rule}`,
        };
      }
    }

    // 1. If bypassPermissions mode, always allow
    if (context.permissionMode === "bypassPermissions") {
      return { behavior: "allow" };
    }

    // 1.1 If acceptEdits mode, allow Edit, Write
    if (context.permissionMode === "acceptEdits") {
      const autoAcceptedTools = [EDIT_TOOL_NAME, WRITE_TOOL_NAME];
      if (autoAcceptedTools.includes(context.toolName)) {
        // Enforce Safe Zone for file operations
        const targetPath = context.toolInput?.file_path as string | undefined;
        const workdir = context.toolInput?.workdir as string | undefined;

        if (targetPath) {
          const { isInside, resolvedPath } = this.isInsideSafeZone(
            targetPath,
            workdir,
          );
          if (!isInside) {
            logger?.info(
              "File operation outside the Safe Zone in acceptEdits mode, falling back to manual confirmation",
              {
                toolName: context.toolName,
                targetPath,
                resolvedPath,
              },
            );
            // Fall through to normal permission check flow to trigger confirmation prompt
          } else {
            return { behavior: "allow" };
          }
        }
      }
    }

    // 1.2 Check if tool call is allowed by persistent or temporary rules
    if (this.isAllowedByRule(context)) {
      return { behavior: "allow" };
    }

    // 1.3 If plan mode, allow Read-only tools and Edit/Write for plan file
    if (context.permissionMode === "plan") {
      const writeTools = [EDIT_TOOL_NAME, WRITE_TOOL_NAME];
      if (writeTools.includes(context.toolName)) {
        const targetPath = context.toolInput?.file_path as string | undefined;

        if (this.planFilePath && targetPath) {
          const absoluteTargetPath = path.resolve(targetPath);
          const absolutePlanPath = path.resolve(this.planFilePath);

          if (absoluteTargetPath === absolutePlanPath) {
            return { behavior: "allow" };
          }
        }

        return {
          behavior: "deny",
          message: `In plan mode, you are only allowed to edit the designated plan file: ${this.planFilePath || "not set"}.`,
        };
      }
    }

    // 2. If not a restricted tool, always allow
    if (!this.isRestrictedTool(context.toolName)) {
      return { behavior: "allow" };
    }

    // 3. If custom callback provided, call it and return result
    if (context.canUseToolCallback) {
      try {
        const decision = await context.canUseToolCallback(context);
        if (decision.behavior !== "allow") {
          logger?.debug("Custom callback returned decision", {
            toolName: context.toolName,
            decision,
          });
        }
        return decision;
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        logger?.error("Error in permission callback", {
          toolName: context.toolName,
          error: errorMessage,
        });
        return {
          behavior: "deny",
          message: "Error in permission callback",
        };
      }
    }

    // 4. For default mode on restricted tools without callback, integrate with CLI confirmation
    // Note: CLI confirmation integration will be implemented in Phase 2
    logger?.warn(
      "No permission callback provided for restricted tool in default mode",
      {
        toolName: context.toolName,
      },
    );
    return {
      behavior: "deny",
      message: `Tool '${context.toolName}' requires permission approval. No permission callback configured.`,
    };
  }

  /**
   * Determine if a tool requires permission checks based on its name
   */
  isRestrictedTool(toolName: string): boolean {
    return (RESTRICTED_TOOLS as readonly string[]).includes(toolName);
  }

  /**
   * Helper method to create a permission context for CLI integration
   */
  createContext(
    toolName: string,
    permissionMode: PermissionMode,
    callback?: PermissionCallback,
    toolInput?: Record<string, unknown>,
  ): ToolPermissionContext {
    let suggestedPrefix: string | undefined;
    if (toolName === BASH_TOOL_NAME && toolInput?.command) {
      const command = String(toolInput.command);
      const parts = splitBashCommand(command);
      // Only suggest prefix for single commands to avoid confusion with complex chains
      if (parts.length === 1) {
        const processedPart = stripRedirections(stripEnvVars(parts[0]));
        suggestedPrefix = getSmartPrefix(processedPart) ?? undefined;
      }
    }

    const context: ToolPermissionContext = {
      toolName,
      permissionMode,
      canUseToolCallback: callback,
      toolInput,
      suggestedPrefix,
    };

    // Set hidePersistentOption for out-of-bounds file operations
    const fileTools = [EDIT_TOOL_NAME, WRITE_TOOL_NAME];
    if (fileTools.includes(toolName)) {
      const targetPath = toolInput?.file_path as string | undefined;
      const workdir = toolInput?.workdir as string | undefined;

      if (targetPath) {
        const { isInside } = this.isInsideSafeZone(targetPath, workdir);
        if (!isInside) {
          context.hidePersistentOption = true;
        }
      }
    }

    // Set hidePersistentOption for dangerous or out-of-bounds bash commands
    if (toolName === BASH_TOOL_NAME && toolInput?.command) {
      const command = String(toolInput.command);
      const workdir = toolInput.workdir as string | undefined;
      const parts = splitBashCommand(command);

      const isDangerous = parts.some((part) => {
        const processedPart = stripRedirections(stripEnvVars(part));
        const commandMatch = processedPart.match(/^(\w+)(\s+.*)?$/);
        if (commandMatch) {
          const cmd = commandMatch[1];
          const args = commandMatch[2]?.trim() || "";

          // Check blacklist
          if (DANGEROUS_COMMANDS.includes(cmd)) {
            return true;
          }

          // Check out-of-bounds for cd and ls
          if (cmd === "cd" || cmd === "ls") {
            const pathArgs =
              (args.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || []).filter(
                (arg) => !arg.startsWith("-"),
              ) || [];

            return pathArgs.some((pathArg) => {
              const cleanPath = pathArg.replace(/^['"](.*)['"]$/, "$1");
              const { isInside } = this.isInsideSafeZone(cleanPath, workdir);
              return !isInside;
            });
          }
        }
        return false;
      });

      if (isDangerous) {
        context.hidePersistentOption = true;
      }
    }

    return context;
  }

  /**
   * Check if a tool call matches a specific permission rule
   */
  private matchesRule(context: ToolPermissionContext, rule: string): boolean {
    // 1. Simple tool name match (e.g., "Bash", "Write")
    if (rule === context.toolName) {
      return true;
    }

    // 2. Tool with pattern match (e.g., "Bash(rm *)", "Read(**/*.env)")
    const match = rule.match(/^(\w+)\((.*)\)$/);
    if (!match) {
      return false;
    }

    const [, toolName, pattern] = match;
    if (toolName !== context.toolName) {
      return false;
    }

    // Handle Bash command rules
    if (toolName === BASH_TOOL_NAME) {
      const command = String(context.toolInput?.command || "");
      const processedPart = stripRedirections(stripEnvVars(command));
      // For Bash commands, we want '*' to match everything including slashes and spaces
      // minimatch's default behavior for '*' is to not match across directory separators
      // We use a regex to replace '*' with '.*' (match anything)
      const regexPattern = pattern
        .replace(/[.+^${}()|[\]\\?]/g, "\\$&") // Escape regex special chars including ?
        .replace(/\*/g, ".*"); // Replace * with .*
      const regex = new RegExp(`^${regexPattern}$`, "s");
      const matched = regex.test(processedPart);
      return matched;
    }

    // Handle path-based rules (e.g., "Read(**/*.env)")
    const pathTools = [
      READ_TOOL_NAME,
      WRITE_TOOL_NAME,
      EDIT_TOOL_NAME,
      LS_TOOL_NAME,
    ];
    if (pathTools.includes(toolName)) {
      const targetPath = (context.toolInput?.file_path ||
        context.toolInput?.path) as string | undefined;

      if (targetPath) {
        return minimatch(targetPath, pattern, { dot: true });
      }
    }

    return false;
  }

  /**
   * Check if a tool call is allowed by persistent or temporary rules
   */
  private isAllowedByRule(context: ToolPermissionContext): boolean {
    const isAllowedByRuleList = (
      ctx: ToolPermissionContext,
      rules: string[],
    ) => {
      if (ctx.toolName === BASH_TOOL_NAME && ctx.toolInput?.command) {
        const command = String(ctx.toolInput.command);
        const parts = splitBashCommand(command);
        if (parts.length === 0) return false;

        const workdir = ctx.toolInput?.workdir as string | undefined;

        return parts.every((part) => {
          const processedPart = stripRedirections(stripEnvVars(part));

          // Check for safe commands
          const commandMatch = processedPart.match(/^(\w+)(\s+.*)?$/);
          if (commandMatch) {
            const cmd = commandMatch[1];
            const args = commandMatch[2]?.trim() || "";

            if (SAFE_COMMANDS.includes(cmd)) {
              if (cmd === "pwd" || cmd === "true" || cmd === "false") {
                return true;
              }

              if (workdir) {
                // For cd and ls, check paths
                const pathArgs =
                  (args.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || []).filter(
                    (arg) => !arg.startsWith("-"),
                  ) || [];

                if (pathArgs.length === 0) {
                  // cd or ls without arguments operates on current dir (workdir)
                  return true;
                }

                const allPathsSafe = pathArgs.every((pathArg) => {
                  // Remove quotes if present
                  const cleanPath = pathArg.replace(/^['"](.*)['"]$/, "$1");
                  const { isInside } = this.isInsideSafeZone(
                    cleanPath,
                    workdir,
                  );
                  return isInside;
                });

                if (allPathsSafe) {
                  return true;
                }
              }
            }
          }

          // Check if this specific part is allowed by any rule
          // We create a temporary context with just this part of the command
          const partContext = {
            ...ctx,
            toolInput: { ...ctx.toolInput, command: processedPart },
          };
          const allowedByRule = rules.some((rule) => {
            return this.matchesRule(partContext, rule);
          });

          if (allowedByRule) return true;

          return !this.isRestrictedTool(ctx.toolName);
        });
      }

      // For other tools, check if any rule matches
      return rules.some((rule) => this.matchesRule(ctx, rule));
    };

    // Check temporary rules first
    if (isAllowedByRuleList(context, this.temporaryRules)) {
      return true;
    }

    // Check persistent allowed rules
    if (isAllowedByRuleList(context, this.allowedRules)) {
      return true;
    }

    // Check default allowed rules
    return isAllowedByRuleList(context, DEFAULT_ALLOWED_RULES);
  }

  /**
   * Expand a bash command into individual permission rules, filtering out safe commands.
   * Used when saving permissions to the allow list.
   *
   * @param command The full bash command string
   * @param workdir The working directory for path safety checks
   * @returns Array of permission rules in "Bash(cmd)" format
   */
  public expandBashRule(command: string, workdir: string): string[] {
    const parts = splitBashCommand(command);
    const rules: string[] = [];

    for (const part of parts) {
      const processedPart = stripRedirections(stripEnvVars(part));

      // Check for safe commands
      const commandMatch = processedPart.match(/^(\w+)(\s+.*)?$/);
      let isSafe = false;

      if (commandMatch) {
        const cmd = commandMatch[1];
        const args = commandMatch[2]?.trim() || "";

        if (SAFE_COMMANDS.includes(cmd)) {
          if (cmd === "pwd" || cmd === "true" || cmd === "false") {
            isSafe = true;
          } else {
            // For cd and ls, check paths
            const pathArgs =
              (args.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || []).filter(
                (arg) => !arg.startsWith("-"),
              ) || [];

            if (pathArgs.length === 0) {
              isSafe = true;
            } else {
              const allPathsSafe = pathArgs.every((pathArg) => {
                const cleanPath = pathArg.replace(/^['"](.*)['"]$/, "$1");
                const { isInside } = this.isInsideSafeZone(cleanPath, workdir);
                return isInside;
              });
              if (allPathsSafe) {
                isSafe = true;
              }
            }
          }
        }
      }

      if (!isSafe) {
        // Check if command is dangerous or out-of-bounds
        const commandMatch = processedPart.match(/^(\w+)(\s+.*)?$/);
        if (commandMatch) {
          const cmd = commandMatch[1];
          const args = commandMatch[2]?.trim() || "";

          if (DANGEROUS_COMMANDS.includes(cmd)) {
            continue;
          }

          if (cmd === "cd" || cmd === "ls") {
            const pathArgs =
              (args.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || []).filter(
                (arg) => !arg.startsWith("-"),
              ) || [];

            const isOutOfBounds = pathArgs.some((pathArg) => {
              const cleanPath = pathArg.replace(/^['"](.*)['"]$/, "$1");
              const { isInside } = this.isInsideSafeZone(cleanPath, workdir);
              return !isInside;
            });

            if (isOutOfBounds) {
              continue;
            }
          }
        }

        const smartPrefix = getSmartPrefix(processedPart);
        if (smartPrefix) {
          rules.push(`Bash(${smartPrefix}*)`);
        } else {
          rules.push(`Bash(${processedPart})`);
        }
      }
    }

    return rules;
  }

  /**
   * Add a persistent permission rule
   * @param rule - The rule to add (e.g., "Bash(ls)")
   */
  public async addPermissionRule(rule: string): Promise<void> {
    if (!this.workdir) {
      throw new Error("Working directory not set in PermissionManager");
    }

    // 1. Expand rule if it's a Bash command
    let rulesToAdd = [rule];
    const bashMatch = rule.match(/^Bash\((.*)\)$/);
    if (bashMatch) {
      const command = bashMatch[1];
      rulesToAdd = this.expandBashRule(command, this.workdir);
    }

    const configurationService = this.container.get<ConfigurationService>(
      "ConfigurationService",
    );

    for (const ruleToAdd of rulesToAdd) {
      // 2. Update PermissionManager state
      const currentRules = this.getAllowedRules();
      const defaultRules = this.getDefaultAllowedRules();
      if (
        !currentRules.includes(ruleToAdd) &&
        !defaultRules.includes(ruleToAdd)
      ) {
        this.updateAllowedRules([...currentRules, ruleToAdd]);

        // 3. Persist to settings.local.json
        try {
          if (configurationService) {
            await configurationService.addAllowedRule(this.workdir, ruleToAdd);
            this._logger?.debug("Persistent permission rule added", {
              rule: ruleToAdd,
            });
          }
        } catch (error) {
          this._logger?.error("Failed to persist permission rule", {
            rule: ruleToAdd,
            error: error instanceof Error ? error.message : String(error),
          });
        }
      }
    }
  }
}
