import { logger } from "../utils/globalLogger.js";
import { Plugin, PluginConfig } from "../types/index.js";
import { PluginLoader } from "../services/pluginLoader.js";
import * as path from "path";
import { SkillManager } from "./skillManager.js";
import { HookManager } from "./hookManager.js";
import { LspManager } from "./lspManager.js";
import { McpManager } from "./mcpManager.js";
import { SlashCommandManager } from "./slashCommandManager.js";
import { MarketplaceService } from "../services/MarketplaceService.js";
import { ConfigurationService } from "../services/configurationService.js";
import { Container } from "../utils/container.js";

export interface PluginManagerOptions {
  workdir: string;
  enabledPlugins?: Record<string, boolean>;
}

export class PluginManager {
  private plugins = new Map<string, Plugin>();
  private workdir: string;
  private enabledPlugins: Record<string, boolean>;

  constructor(
    private container: Container,
    options: PluginManagerOptions,
  ) {
    this.workdir = options.workdir;
    this.enabledPlugins = options.enabledPlugins || {};
  }

  private get skillManager(): SkillManager | undefined {
    return this.container.get<SkillManager>("SkillManager");
  }

  private get hookManager(): HookManager | undefined {
    return this.container.get<HookManager>("HookManager");
  }

  private get lspManager(): LspManager | undefined {
    return this.container.get<LspManager>("LspManager");
  }

  private get mcpManager(): McpManager | undefined {
    return this.container.get<McpManager>("McpManager");
  }

  private get slashCommandManager(): SlashCommandManager | undefined {
    return this.container.get<SlashCommandManager>("SlashCommandManager");
  }

  private get configurationService(): ConfigurationService | undefined {
    return this.container.get<ConfigurationService>("ConfigurationService");
  }

  /**
   * Update enabled plugins configuration
   */
  updateEnabledPlugins(enabledPlugins: Record<string, boolean>): void {
    this.enabledPlugins = enabledPlugins;
  }

  /**
   * Load plugins installed via marketplace
   */
  private async loadInstalledPlugins(): Promise<void> {
    try {
      // If configurationService is provided, use it to get the latest merged enabled plugins
      if (this.configurationService) {
        this.enabledPlugins = this.configurationService.getMergedEnabledPlugins(
          this.workdir,
        );
      }

      const marketplaceService = new MarketplaceService();
      const installedRegistry = await marketplaceService.getInstalledPlugins();

      for (const p of installedRegistry.plugins) {
        const pluginId = `${p.name}@${p.marketplace}`;
        if (this.enabledPlugins[pluginId] !== true) {
          logger?.info(`Plugin ${pluginId} is not enabled via configuration`);
          continue;
        }
        await this.loadSinglePlugin(p.cachePath);
      }
    } catch (error) {
      logger?.error("Failed to load installed plugins:", error);
    }
  }

  /**
   * Load a single plugin from an absolute path
   */
  private async loadSinglePlugin(absolutePath: string): Promise<void> {
    try {
      const manifest = await PluginLoader.loadManifest(absolutePath);

      if (this.plugins.has(manifest.name)) {
        // If already loaded (e.g. via explicit config), skip
        logger?.warn(`Plugin with name '${manifest.name}' is already loaded`);
        return;
      }

      const plugin: Plugin = {
        ...manifest,
        path: absolutePath,
        commands: PluginLoader.loadCommands(absolutePath),
        skills: await PluginLoader.loadSkills(absolutePath),
        lspConfig: await PluginLoader.loadLspConfig(absolutePath),
        mcpConfig: await PluginLoader.loadMcpConfig(absolutePath),
        hooksConfig: await PluginLoader.loadHooksConfig(absolutePath),
      };

      // Register components with managers
      if (this.slashCommandManager && plugin.commands.length > 0) {
        this.slashCommandManager.registerPluginCommands(
          plugin.name,
          plugin.commands,
        );
      }

      if (this.skillManager && plugin.skills.length > 0) {
        this.skillManager.registerPluginSkills(plugin.skills);
      }

      if (this.lspManager && plugin.lspConfig) {
        for (const [language, config] of Object.entries(plugin.lspConfig)) {
          this.lspManager.registerServer(language, config);
        }
      }

      if (this.mcpManager && plugin.mcpConfig) {
        for (const [name, config] of Object.entries(
          plugin.mcpConfig.mcpServers,
        )) {
          this.mcpManager.addServer(name, config);
        }
      }

      if (this.hookManager && plugin.hooksConfig) {
        this.hookManager.registerPluginHooks(plugin.hooksConfig);
      }

      this.plugins.set(manifest.name, plugin);
      logger?.info(`Loaded plugin: ${manifest.name} v${manifest.version}`);
    } catch (error) {
      logger?.error(`Failed to load plugin from ${absolutePath}`, error);
    }
  }

  /**
   * Load plugins from configuration
   * @param configs Array of plugin configurations
   */
  async loadPlugins(configs: PluginConfig[]): Promise<void> {
    // Load plugins from configuration (e.g. --plugin-dir) first to give them higher priority
    for (const config of configs) {
      if (config.type !== "local") {
        logger?.warn(`Unsupported plugin type: ${config.type}`);
        continue;
      }

      const absolutePath = path.isAbsolute(config.path)
        ? config.path
        : path.resolve(this.workdir, config.path);

      await this.loadSinglePlugin(absolutePath);
    }

    // Load installed plugins from marketplace
    await this.loadInstalledPlugins();
  }

  /**
   * Get all loaded plugins
   */
  getPlugins(): Plugin[] {
    return Array.from(this.plugins.values());
  }

  /**
   * Get a plugin by name
   */
  getPlugin(name: string): Plugin | undefined {
    return this.plugins.get(name);
  }
}
